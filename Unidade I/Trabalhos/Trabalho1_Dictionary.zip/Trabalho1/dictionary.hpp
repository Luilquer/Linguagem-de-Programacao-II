#include <vector>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>

using namespace std;

vector<string> LoadDictionary(const char* filename);
