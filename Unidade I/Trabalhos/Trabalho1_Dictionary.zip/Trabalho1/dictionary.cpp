#include "dictionary.hpp"

vector<string> LoadDictionary(const char *filename)
{
  vector<string> lista;
  ifstream file;
  file.open(filename);

  if (file.is_open())
  {
    string tmp;

    while (getline(file, tmp))
    {
      lista.push_back(tmp);
    }

    lista.erase(lista.begin() + 0);
  }

  return lista;
}
