#include "dictionary.hpp"
#include <algorithm>


int main(int argc, char* argv[])
{
    string arquivo1;
    cin >> arquivo1;
    vector<string> lista1 = LoadDictionary(arquivo1.c_str());

    string arquivo2;
    cin >> arquivo2;
    vector<string> lista2 = LoadDictionary(arquivo2.c_str());

    for(size_t i=0; i < lista2.size(); i++)
    {
        lista1.push_back(lista2.at(i));
    }

    lista2.clear();


    unsigned int tamPalavra = 0;
    cin >> tamPalavra;

    sort(lista1.begin(), lista1.end());

    int duplicate = 0;
    int filtro = lista1.size();
    size_t i=0;

    while(i < lista1.size()-1)
    {
        if((lista1.at(i).length() >= tamPalavra) && (lista1.at(i) == lista1.at(i+1)))
        {
            cout << lista1.at(i) << "==" << lista1.at(i) << endl;
            lista1.erase(lista1.begin()+ i);

            duplicate++;
        }
        else

            i++;
    }

    filtro -= duplicate;
    cout << "duplicatelicates:_" << duplicate << endl;
    cout << "Filtered_Words:_" << filtro << endl;

    return 0;
}
