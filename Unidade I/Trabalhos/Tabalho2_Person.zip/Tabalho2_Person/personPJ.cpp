#include "personPJ.hpp"

//Pessoas jur�dicas possuem os seguintes atributos:
/*Nome, Raz�o Social, CNPJ, Endere�o,
Data de Abertura, CapitalSocial.
*/

PessoaJ inserePessoaPJ()
{
    PessoaJ pjnovo;

    if(fdebug) cout << "Nome: " << endl;
    getline(cin, pjnovo.nome);

    if(fdebug) cout << "Razao social: " << endl;
    getline(cin, pjnovo.razaoSocial);

    if(fdebug) cout << "CNPJ: " << endl;
    getline(cin, pjnovo.cnpj);

    if(fdebug) cout << "Endereco: " << endl;
    getline(cin, pjnovo.endereco);

    if(fdebug) cout << "Data de abertura: " << endl;
    getline(cin, pjnovo.dataAbertura);

    if(fdebug) cout << "Capital Social(R$): " << endl;
    getline(cin, pjnovo.capital);

    return pjnovo;

}
