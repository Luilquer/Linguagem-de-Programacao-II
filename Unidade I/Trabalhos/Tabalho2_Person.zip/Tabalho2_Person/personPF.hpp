#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

#define fdebug 0 // quando 0 - release   /    1 - produ��o

struct PessoaF
{
    string nome;
    string cpf;
    string endereco;
    string data;
    string estadoCivil;

};


PessoaF inserePessoaPF();




