#include <iostream>
#include <fstream>
#include "personPF.hpp"
#include "personPJ.hpp"
#include "pessoaFJ.hpp"

using namespace std;

int main()
{
    vector<PessoaF> listaF;
    vector<PessoaJ> listaJ;
    vector<PessoaFJ> listaFJ;

    //Criar e abrir o arquivo de texto
    ofstream Arquivo("arquivo.txt");

    for(;;)
    {
         if(fdebug) cout << "--------------------------"<< endl;
         if(fdebug) cout << listaF.size() << endl;
         if(fdebug) cout << "Digite uma opcao: " << endl;
         if(fdebug) cout << "1. Insere Pessoa F�sica" << endl;
         if(fdebug) cout << "2. Insere Pessoa Jur�dica" << endl;
         if(fdebug) cout << "3. Remover Pessoa" << endl;
         if(fdebug) cout << "4. Pesquisar Nome" << endl;
         if(fdebug) cout << "5. Visualizar Alfabetico" << endl;
         if(fdebug) cout << "6. Visualizar por Grupo" << endl;
         if(fdebug) cout << "7. Sair" << endl;
         if(fdebug) cout << "--------------------------" << endl;


        char ch;
        cin >> ch;
        //limpando buffer
        cin.ignore();

         if(ch == '1')
        {
            PessoaF pfnovo = inserePessoaPF();
            listaF.push_back(pfnovo);

            //Salvando no arquivo.txt
            Arquivo << pfnovo.nome << endl;
            Arquivo << pfnovo.cpf << endl;
            Arquivo << pfnovo.endereco << endl;
            Arquivo << pfnovo.data << endl;
            Arquivo << pfnovo.estadoCivil << endl << endl;

            //Cria um objeto FJ e atribui ao VETOR pfAndPJ
            PessoaFJ novoFJ = insere("PF", pfnovo.nome, listaF.size() - 1);
            listaFJ.push_back(novoFJ);

        }
        //inserir pJ
        if(ch == '2')
        {
            PessoaJ pjnovo = inserePessoaPJ();
            listaJ.push_back(pjnovo);

            //Salvando no arquivo.txt
            Arquivo << pjnovo.nome << endl;
            Arquivo << pjnovo.razaoSocial << endl;
            Arquivo << pjnovo.cnpj << endl;
            Arquivo << pjnovo.endereco << endl;
            Arquivo << pjnovo.dataAbertura << endl;
            Arquivo << pjnovo.capital << endl << endl;

            PessoaFJ novoFJ = insere("PJ", pjnovo.nome, listaJ.size() - 1);
            listaFJ.push_back(novoFJ);

        }

        //Remover pessoa
        if(ch == '3')
        {
            //salvando na variavel string
            if(fdebug) cout << "Remover da lista Fisica ou Juridica(F/J): " << endl;
            string tipo;
            getline(cin, tipo);

            //Pegando a posi��o
            if(fdebug) cout << "Posicao[]: " << endl;
            int posicao;
            cin >> posicao;

            //RETIRANDO O BUFFER DO TECLADO
            cin.ignore();

            //Fazendo a verifica��o da lista
            if(tipo == "F")
            {

                if(posicao > (listaF.size() - 1))
                {
                    if(fdebug) cout << "Nao foi possivel remover" << endl;
                }
                else
                {
                    //Deletando na lista F�sica
                    listaF.erase(listaF.begin() + posicao);
                }
            }
            //Lista Juridica
            else if(tipo == "J")
            {
                if(posicao > (listaJ.size() - 1))
                {
                    if(fdebug) cout << "Nao foi possivel remover." << endl;
                }
                else
                {
                    //Deletando na lista j�ridica
                    listaJ.erase(listaJ.begin() + posicao);
                }

            }
        }

        //Pesuisar por nome
        if(ch == '4')
        {
            if(fdebug) cout << "Nome: " << endl;
            string nome;
            getline(cin, nome);

            //Verificando se existe o NOME
            for(size_t i = 0; i < listaF.size(); i++)
            {
                if (listaF[i].nome.find(nome, 0) != string::npos)
                {
                    cout << listaF.at(i).nome << " -> "  << "PF pos: " << i << endl;
                }
            }

            //Verificando se existe o NOME
            for(size_t i = 0; i < listaJ.size(); i++)
            {
                if(listaJ[i].nome.find(nome, 0) != string::npos)
                {
                    cout << listaJ.at(i).nome << " -> " << "PJ pos: " << i << endl;
                }
            }
        }

        //Visualizar alfabetico
        if(ch == '5')
        {

            //FAZENDO A ORDENACAO
           sort(listaFJ.begin(), listaFJ.end());

           //LISTANDO O RESULTADO
           for(size_t i = 0; i < listaFJ.size(); i++)
            {
                cout << listaFJ.at(i).nome << " -> "
                << listaFJ.at(i).tipo << " pos: " << listaFJ.at(i).posicao << endl;
            }

        }

        //Visualizar por grupo
        if(ch == '6')
        {
            cout << "Pessoa Fisica:" << endl;
            for(size_t i = 0; i < listaF.size(); i++)
            {
                cout << listaF.at(i).nome << " -> " << "PF Pos: " << i << endl;
            }

            cout << endl;


            cout << "Pessoa Juridica:" << endl;
            for(size_t i = 0; i < listaJ.size(); i++)
            {
                cout << listaJ.at(i).nome << " -> " << "PJ Pos: " << i << endl;
            }
        }
        //Sair do programa
        if(ch == '7')
        {
            //Fechando o arquivo
            Arquivo.close();
            return 1;
        }

    }

    return 0;
}
