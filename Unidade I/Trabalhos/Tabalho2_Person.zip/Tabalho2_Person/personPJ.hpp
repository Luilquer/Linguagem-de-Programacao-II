#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

#define fdebug 0 // quando 0 - release   /    1 - produ��o

//Pessoas jur�dicas possuem os seguintes atributos:
/*Nome, Raz�o Social, CNPJ, Endere�o,
Data de Abertura, CapitalSocial.
*/

struct PessoaJ
{
    string nome;
    string razaoSocial;
    string cnpj;
    string endereco;
    string dataAbertura;
    string capital;
};


PessoaJ inserePessoaPJ();
