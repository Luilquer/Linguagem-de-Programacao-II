#include "pessoaFJ.hpp"

//CRIANDO UMA FUNCAO DE INSERIR O TIPO DE CONTATO,
//NOME E A POSICAO QUE ELE PERTENCIA NO VETOR EM QUAL ELE PERTENCE (PF OU PJ)
PessoaFJ insere(string tipo, string nome, int posicao)
{
    PessoaFJ novoFJ;

    novoFJ.tipo = tipo;
    novoFJ.nome = nome;
    novoFJ.posicao = posicao;

    return novoFJ;

}

bool operator<(const PessoaFJ &l1, const PessoaFJ &l2)
{
    return l1.nome < l2.nome;
}
