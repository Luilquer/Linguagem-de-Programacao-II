#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <algorithm>
#include <vector>
#include <string>
#include <utility>

using namespace std;

#define fdebug 0      // quando 0 - release   /    1 - produ��o

struct PessoaFJ
{
    string tipo;
    string nome;
    int posicao;
};

//CRIANDO UMA FUNCAO DE INSERIR O TIPO DE CONTATO,
//NOME E A POSICAO QUE ELE PERTENCIA NO VETOR EM QUAL ELE PERTENCE (PF OU PJ)
PessoaFJ insere(string tipo, string nome, int posicao);

//CRIANDO UM OPERATOR DE COMPARACAO < PARA OS VETORES DO TIPO PFANDPJ
bool operator<(const PessoaFJ &l1, const PessoaFJ &l2);
