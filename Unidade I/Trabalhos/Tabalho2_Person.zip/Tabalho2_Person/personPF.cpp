#include "personPF.hpp"

PessoaF inserePessoaPF()
{
    PessoaF pfnovo;

    if(fdebug) cout << "Nome: " << endl;
    getline(cin, pfnovo.nome);

    if(fdebug) cout << "CPF: " << endl;
    getline(cin, pfnovo.cpf);

    if(fdebug) cout << "Endereco: " << endl;
    getline(cin, pfnovo.endereco);

    if(fdebug) cout << "Data de nascimento: " << endl;
    getline(cin, pfnovo.data);

    if(fdebug) cout << "Estado civil(S/C/D): " << endl;
    getline(cin, pfnovo.estadoCivil);

    return pfnovo;
}




