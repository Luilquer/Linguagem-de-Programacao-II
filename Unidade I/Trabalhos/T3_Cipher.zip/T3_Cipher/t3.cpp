#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

#define fdebug 1  

using namespace std;

int main()
{
    //vetor de pair (sequencia de par ordenado)
    vector < pair < char, char > > tabela; //lockuptable
    //variavel para armazenar cada caracter do arquivo 
    char ch;

    //1. Ler alfabeto
    if(fdebug) cout << "enter with an alphabet: "; 
    string pathfile;
    cin >> pathfile;
    cout << "\n";
    
    //tipo para leitura de arquivos
    ifstream pfile(pathfile); 

    //Verificando se a leitura foi realizada com exito
    if(pfile.is_open() == false)
    {
        if(fdebug) cout << "Erro, arquivo alfabeto não encontrado! " << endl;

        return 1;
    }
    
    while(pfile.get(ch)) //Enquanto conter caracter 
    {
        //verifica se tem espaço entre os caracteres, e continua o programa sem considera-los
        if(ch == '\n') 
        {
            continue;
        }
        
        //criando um par ordenado para inicializa-lo
        pair<char, size_t> p;
        //A primeira posição do pair recebe os caracteres armazenados em ch
        p.first = ch;
        //A segunda recebe uma traço, para sinalizar 
        p.second = '-';
        //insere na ultima posição do vector tabela o pair 'p'
        tabela.push_back(p);    
    }

    //Fechando a leitura do arquivo, para em seguida reutizar a mesma variavel
    pfile.close();

    //Exibindo o lockuptable.first
    if (fdebug)
        for (size_t i = 0; i < tabela.size(); i++)
        {
            cout << tabela.at(i).first << endl;
        }

    cout << endl;
    
    //2. Leitura do manuscrito
    if(fdebug) cout << "enter with a manuscript: "; 
    string pathfileman;
    cin >> pathfileman;
     //tipo para leitura de arquivos
    pfile.open(pathfileman); 

    if(pfile.is_open() == false)
    {
        if(fdebug) cout << "Erro, manuscrito não encontrado!" << endl;
        return 1;
    }    

    stringstream manuscrito;
    while(pfile.get(ch))
    {
        if (ch == '\n')
        {
            continue;
        }
            
        manuscrito << ch;
        
    }

    // Exibir o manuscrito /obter o conteúdo do que está armazenado na stream str()
    cout << manuscrito.str() << endl;
    pfile.close();

    
    //3. Calcular a frequência dos caracteres no manuscrito.txt
    //Tabela frequencia até o tamanho da tabela ascii
    vector < pair< size_t, size_t> > tabelaF(256);

    for(size_t i = 0; i < tabelaF.size(); i++)
    {
        tabelaF.at(i).first = i;
        tabelaF.at(i).second = 0;
    }

    //vetor para a ordenação
    vector<size_t> aux;
    for(size_t i = 0; i < manuscrito.str().length(); i++)
    {
        //variavel char, recebe os caracters armazenados no manuscrito na posição 'i'
        char ch = manuscrito.str().at(i);
        //Contagem na segunda posição da tabelaF
        tabelaF.at(ch).second++;
    }

    //For para percorre até o tamanho da tabela frequencia
    for(size_t i = 0; i < tabelaF.size(); i++)
    {
        //Considerando apenas os que são maiores que zero
        if(tabelaF.at(i).second > 0)
        {
            //Salvando no vector 
            aux.push_back(tabelaF.at(i).second);
        }
    }

    //Metodo para ordenar o vector aux
    sort(aux.begin(), aux.end());

    //Colocar em ordem decrescente, vector decre 
    vector<size_t> decre;

    for(size_t i = 0; i < aux.size(); i++)
    {
        size_t index = aux.size() - i - 1;
        decre.push_back(aux.at(index));
    }

    for(size_t i = 0; i < aux.size(); i++)
    {
        aux.at(i) = decre.at(i);
    }


    //4. Utilizar a frequência (descendente) para construir o lockuptable (associação entre alfabeto X código)
    //tamanho da tabela (lockuptable) é maior ou igual a quantidade de
    // caracteres presentes no manuscrito
    if(aux.size() <= tabela.size())
    {
        for(size_t i = 0; i < aux.size(); i++)
        {
            for(size_t j = 0; j < tabelaF.size(); j++)
            {
                //-1 -j escrever na ordem inversa
                if(aux.at(i) == tabelaF.at(tabelaF.size() - 1 - j).second)
                {
                    tabela.at(i).second = (char)tabelaF.at(tabelaF.size() - 1 - j).first;
                    //para não duplicar o tamanho dos caracteres repetidos
                    aux.at(i) = -1;
                    //frequencia dele = 0, para que nao conte novamente
                    tabelaF.at(tabelaF.size() - 1 - j).second = 0;
                    
                }
            }
        }


        //5. Encriptar o texto manuscrito.txt e mostrar em tela
        //Colocando em ordem decrescente
        for (size_t i = 0; i < aux.size(); i++)
        {
            aux.at(i) = decre.at(i);
        }
        cout << "\n";

        //Exibindo a frequencia em ordem decrescente
        if (fdebug) cout << "Manuscript Frequency in descending order (removing 0 freqs):" << endl;

        for(size_t i = 0; i < aux.size(); i++)
        {
            cout << tabela.at(i).second << " -> " << aux.at(i) << "\n";
        }

        cout << "\n";

       
        cout << "Lockup table:" << endl;
        for(size_t i = 0; i < tabela.size(); i++)
        {
            cout << tabela.at(i).second << " -> " << tabela.at(i).first << "\n";
        }

        cout << "\n";


        
        cout << "Encrypted manuscript:" << endl;
        string encriptado;

        for(size_t i = 0; i < manuscrito.str().size(); i++)
        {
            for(size_t j = 0; j < tabela.size(); j++)
            {

                if(manuscrito.str().at(i) == tabela.at(j).second)
                {
                    encriptado = tabela.at(j).first;
                    cout << tabela.at(j).first;

                }
            }

        }

    }
    else
    {
        
        cout << "Manuscript Frequency in descending order (removing 0 freqs):" << endl;
        for(size_t i = 0; i < aux.size(); i++)
        {
            for(size_t j = 0; j < tabelaF.size(); j++)
            {
                if(aux.at(i) == tabelaF.at(tabelaF.size() - 1 - j).second)
                {
                    cout << (char)tabelaF.at(tabelaF.size() - 1 - j).first << " -> " << aux.at(i) << endl;
                    aux.at(i) = 999999999;
                    tabelaF.at(tabelaF.size() - 1 - j).second = 0;
                }
            }
        }

        cout << "Error, alphabet with insufficient chars to be encoded";
    }

    pfile.close(); 
   
    return 0;
}


