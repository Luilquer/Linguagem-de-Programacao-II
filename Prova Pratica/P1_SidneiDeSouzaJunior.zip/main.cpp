//
//  main.cpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#include <iostream>
#include <list>
#include "Fila.hpp"
#include "Pilha.hpp"

#define fdebug 0

int main() {

    // Fila fila;
    // Pilha pilha;
    EstruturaDados *es = new EstruturaDados();
    Fila *fila = (Fila*) es;
    Pilha *pilha = (Pilha*) es;

    while (true) {
        if (fdebug) cout << "\nEscolha uma das opcoes: " << endl;
        if (fdebug) cout << "1 - Fila" << endl;
        if (fdebug) cout << "2 - Pilha" << endl;
        if (fdebug) cout << "0 - Sair\n" << endl;

        char ch;
        cin >> ch;
        cin.ignore();

        //Fila
        if (ch == '1') {    
            while (true) {                    

                if (fdebug) cout << "\nInsira uma opcao para realizar uma funcao na fila:" << endl;
                if (fdebug) cout << "1 - Inserir" << endl;
                if (fdebug) cout << "2 - Remover" << endl;
                if (fdebug) cout << "3 - Limpar" << endl;
                if (fdebug) cout << "4 - Imprimir" << endl;
                if (fdebug) cout << "5 - Mostrar Tamanho da Fila" << endl;
                if (fdebug) cout << "0 - Retornar Menu Anterior\n" << endl;

                char ch2;
                cin >> ch2;
                cin.ignore();

                //INSERIR FILA
                if (ch2 == '1') {
                    if (fdebug) cout << "\nDigite um numero:" << endl;
                    
                    int num;
                    cin >> num;
                    cin.ignore();        

                    // fila.inserir(num);
                    fila->inserir(num);
                }

                //REMOVER A PRIMEIRA POSICAO DA FILA
                if (ch2 == '2') {
                    // fila.remover();
                    fila->remover();
                }

                //LIMPAR FILA
                if (ch2 == '3') {
                    // fila.resetar();
                    fila->resetar();
                }

                //IMPRIMIR FILA
                if (ch2 == '4') {
                    // fila.imprimir();
                    fila->imprimir();
                }

                //MOSTRAR TAMANHO DA FILA
                if (ch2 == '5') {
                    // fila.getTamanho();
                    fila->getTamanho();
                }

                //Retornar Menu Anterior
                if (ch2 == '0') {
                    break;
                }
                
            }

        }

        //Pilha
        if (ch == '2') {

            while (true) {                    

                if (fdebug) cout << "\nInsira uma opcao para realizar uma funcao na pilha:" << endl;
                if (fdebug) cout << "1 - Inserir" << endl;
                if (fdebug) cout << "2 - Remover" << endl;
                if (fdebug) cout << "3 - Limpar" << endl;
                if (fdebug) cout << "4 - Imprimir" << endl;
                if (fdebug) cout << "5 - Mostrar Tamanho da Pilha" << endl;
                if (fdebug) cout << "0 - Retornar Menu Anterior\n" << endl;

                char ch2;
                cin >> ch2;
                cin.ignore();

                //INSERIR PILHA
                if (ch2 == '1') {
                    if (fdebug) cout << "\nDigite um numero:" << endl;
                    
                    int num;
                    cin >> num;
                    cin.ignore();        

                    // pilha.inserir(num);
                    fila->inserir(num);
                }

                //REMOVER ULTIMA POSICAO DA PILHA
                if (ch2 == '2') {
                    // pilha.remover();
                    pilha->remover();
                }

                //LIMPAR PILHA
                if (ch2 == '3') {
                    // pilha.resetar();
                    pilha->resetar();
                }

                //IMPRIMIR PILHA
                if (ch2 == '4') {
                    // pilha.imprimir();
                    pilha->imprimir();
                }

                //MOSTRAR TAMANHO DA PILHA
                if (ch2 == '5') {
                    // pilha.getTamanho();
                    pilha->getTamanho();
                }

                //Retornar Menu Anterior
                if (ch2 == '0') {
                    break;
                }
                
            }

        }

        //Sair
        if (ch == '0') {
            delete es;
            break;
        }
            
    }

    return 0;    
}