//
//  EstruturaDados.hpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#ifndef ESTRUTURADADOS_H
#define ESTRUTURADADOS_H

#include <iostream>
#include <list>

using namespace std;

class EstruturaDados {

protected:
    list<int> m_lista;

public:
    EstruturaDados();
    EstruturaDados(list<int> l);
    ~EstruturaDados();

    void resetar();  

    void getTamanho();       

};

#endif