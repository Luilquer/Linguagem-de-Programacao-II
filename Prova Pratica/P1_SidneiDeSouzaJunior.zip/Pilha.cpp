//
//  Pilha.cpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#include "Pilha.hpp" 

Pilha::~Pilha() {
}

//LIFO
Pilha::Pilha() {
    this->m_lista.empty();
}

void Pilha::inserir(int valor) {
    m_lista.push_back(valor);
}

void Pilha::remover() {
    m_lista.pop_back();
}

void Pilha::imprimir() {
    for (list<int>::iterator it = m_lista.begin(); it != m_lista.end(); it++) {
        cout << *it << endl;
    }    
}