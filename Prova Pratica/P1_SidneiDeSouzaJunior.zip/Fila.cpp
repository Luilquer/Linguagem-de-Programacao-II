//
//  Fila.cpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#include "Fila.hpp" 

Fila::~Fila() {
}

//FIFO
Fila::Fila() {
    this->m_lista.empty();
}

void Fila::inserir(int valor) {
    m_lista.push_back(valor);
}

void Fila::remover() {
    m_lista.pop_front();
}

void Fila::imprimir() {
    for (list<int>::iterator it = m_lista.begin(); it != m_lista.end(); it++) {
        cout << *it << endl;
    }        
}