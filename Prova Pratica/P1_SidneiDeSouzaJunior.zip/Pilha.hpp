//
//  Pilha.hpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#ifndef PILHA_H
#define PILHA_H

#include "EstruturaDados.hpp"

using namespace std;

class Pilha: public EstruturaDados {

protected:

public:
    Pilha();
    ~Pilha();

    //LIFO
    void inserir(int valor);

    void remover();

    void imprimir();

};

#endif