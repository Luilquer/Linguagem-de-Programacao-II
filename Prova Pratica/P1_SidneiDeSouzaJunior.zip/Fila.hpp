//
//  Fila.hpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#ifndef FILA_H
#define FILA_H

#include "EstruturaDados.hpp"

using namespace std;

class Fila: public EstruturaDados {

protected:

public:
    Fila();
    ~Fila();

    //FIFO
    void inserir(int valor);

    void remover();

    void imprimir();

};

#endif