//
//  EstruturaDados.cpp
//
//  Created by Sidnei de Souza Junior on 17/11/20.
//  Copyright © 2020 Sidnei de Souza Junior. All rights reserved.
//

#include "EstruturaDados.hpp" 

EstruturaDados::~EstruturaDados() {
}

EstruturaDados::EstruturaDados() {
    this->m_lista.empty();
}

EstruturaDados::EstruturaDados(list<int> l) {
    this->m_lista = l;
}

void EstruturaDados::resetar() {
    m_lista.clear();
}   

void EstruturaDados::getTamanho() {
    cout << "\nTamanho: " << m_lista.size() << endl;
}  