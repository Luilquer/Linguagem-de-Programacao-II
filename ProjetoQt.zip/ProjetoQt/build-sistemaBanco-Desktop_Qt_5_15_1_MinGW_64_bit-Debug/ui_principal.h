/********************************************************************************
** Form generated from reading UI file 'principal.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRINCIPAL_H
#define UI_PRINCIPAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_principal
{
public:
    QAction *actionUsuario;
    QAction *actionBebida;
    QAction *actionFornecedor;
    QAction *actionEndereco;
    QWidget *centralwidget;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QMenu *menuGest_o;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *principal)
    {
        if (principal->objectName().isEmpty())
            principal->setObjectName(QString::fromUtf8("principal"));
        principal->resize(800, 600);
        actionUsuario = new QAction(principal);
        actionUsuario->setObjectName(QString::fromUtf8("actionUsuario"));
        actionBebida = new QAction(principal);
        actionBebida->setObjectName(QString::fromUtf8("actionBebida"));
        actionFornecedor = new QAction(principal);
        actionFornecedor->setObjectName(QString::fromUtf8("actionFornecedor"));
        actionEndereco = new QAction(principal);
        actionEndereco->setObjectName(QString::fromUtf8("actionEndereco"));
        centralwidget = new QWidget(principal);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(220, 130, 75, 23));
        principal->setCentralWidget(centralwidget);
        menubar = new QMenuBar(principal);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        menuGest_o = new QMenu(menubar);
        menuGest_o->setObjectName(QString::fromUtf8("menuGest_o"));
        principal->setMenuBar(menubar);
        statusbar = new QStatusBar(principal);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        principal->setStatusBar(statusbar);

        menubar->addAction(menuGest_o->menuAction());
        menuGest_o->addAction(actionUsuario);
        menuGest_o->addAction(actionBebida);
        menuGest_o->addAction(actionFornecedor);
        menuGest_o->addAction(actionEndereco);

        retranslateUi(principal);

        QMetaObject::connectSlotsByName(principal);
    } // setupUi

    void retranslateUi(QMainWindow *principal)
    {
        principal->setWindowTitle(QCoreApplication::translate("principal", "Principal", nullptr));
        actionUsuario->setText(QCoreApplication::translate("principal", "Usuario", nullptr));
        actionBebida->setText(QCoreApplication::translate("principal", "Bebida", nullptr));
        actionFornecedor->setText(QCoreApplication::translate("principal", "Fornecedor", nullptr));
        actionEndereco->setText(QCoreApplication::translate("principal", "Endereco", nullptr));
        pushButton->setText(QCoreApplication::translate("principal", "Login", nullptr));
        menuGest_o->setTitle(QCoreApplication::translate("principal", "Gest\303\243o", nullptr));
    } // retranslateUi

};

namespace Ui {
    class principal: public Ui_principal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRINCIPAL_H
