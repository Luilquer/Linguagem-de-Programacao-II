#ifndef LOGAR_H
#define LOGAR_H

#include <QDialog>
#include "conexao.h"

namespace Ui {
class logar;
}

class logar : public QDialog
{
    Q_OBJECT

public:
    explicit logar(QWidget *parent = nullptr);
    ~logar();
    bool logado;
    Conexao con;
    QString nome,acesso;
    int id;

private slots:
    void on_btn_logar_clicked();

    void on_btn_cancelar_clicked();

private:
    Ui::logar *ui;
};

#endif // LOGAR_H


