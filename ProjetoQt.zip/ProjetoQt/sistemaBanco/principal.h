#ifndef PRINCIPAL_H
#define PRINCIPAL_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class principal; }
QT_END_NAMESPACE

class principal : public QMainWindow
{
    Q_OBJECT

public:
    principal(QWidget *parent = nullptr);
    ~principal();
    bool logado;

private slots:
    void on_pushButton_clicked();

    void on_actionUsuario_triggered();

    void on_actionBebida_triggered();

    void on_actionFornecedor_triggered();

    void on_actionEndereco_triggered();

private:
    Ui::principal *ui;
};
#endif // PRINCIPAL_H
