#include "bebida.h"
#include "ui_bebida.h"
#include <QMessageBox>
#include <QtSql>

bebida::bebida(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bebida)
{
    ui->setupUi(this);
    //abrir o banco de dados
    if(!con.aberto()){
        if(!con.abrir()){
            QMessageBox::warning(this, "ERROR", "Erro ao abrir banco de Dados");
        }
    }
}

bebida::~bebida()
{
    delete ui;
}

void bebida::on_btn_salvar_clicked()
{
    QString nome=ui->txt_nome->text();
    QString valor=ui->txt_valor->text();
    QString id=ui->txt_id->text();


    //INSERIR NA TABELA
    QSqlQuery query;
    query.prepare("insert into Bebida (nome,valor,id_fornecedor) values"
                  "('"+nome+"','"+valor+"','"+id+"')");

    if(!query.exec()){
         QMessageBox::critical(this, "ERRO", "Erro ao inserir no Banco de Dados");
    }else{
        QMessageBox::information(this, "GRAVADO", "inserido no Banco de Dados");
        //limpar todos os campos e posicipn
        ui->txt_nome->clear();
        ui->txt_valor->clear();
        ui->txt_id->clear();
        ui->txt_nome->setFocus();

    }

}

void bebida::on_btn_cancelar_clicked()
{
    //limpar todos os campos e posicipn
    ui->txt_nome->clear();
    ui->txt_valor->clear();
    ui->txt_id->clear();
    ui->txt_nome->setFocus();
}
