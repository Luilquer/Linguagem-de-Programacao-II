#include "usuario.h"
#include "ui_usuario.h"
#include <QMessageBox>
#include <QtSql>

usuario::usuario(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::usuario)
{
    ui->setupUi(this);
    //abrir o banco de dados
    if(!con.aberto()){
        if(!con.abrir()){
            QMessageBox::warning(this, "ERROR", "Erro ao abrir banco de Dados");
        }
    }

}

usuario::~usuario()
{
    delete ui;
}

void usuario::on_btn_salvar_clicked()
{

    QString username=ui->txt_username->text();
    QString senha=ui->txt_senha->text();
    QString id=ui->txt_id->text();


    //INSERIR NA TABELA
    QSqlQuery query;
    query.prepare("insert into Usuario (username,senha,id_fornecedor) values"
                  "('"+username+"','"+senha+"','"+id+"')");

    if(!query.exec()){
         QMessageBox::critical(this, "ERRO", "Erro ao inserir no Banco de Dados");
    }else{
        QMessageBox::information(this, "GRAVADO", "inserido no Banco de Dados");
        //limpar todos os campos e posicipn
        ui->txt_username->clear();
        ui->txt_senha->clear();
        ui->txt_id->clear();
        ui->txt_username->setFocus();

    }


}

void usuario::on_btn_cancelar_clicked()
{
    //limpar todos os campos e posicipn
    ui->txt_username->clear();
    ui->txt_senha->clear();
    ui->txt_id->clear();
    ui->txt_username->setFocus();
}
