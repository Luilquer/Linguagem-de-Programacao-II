#ifndef FORNECEDOR_H
#define FORNECEDOR_H

#include <QDialog>
#include <QObject>
#include "conexao.h"

namespace Ui {
class fornecedor;
}

class fornecedor : public QDialog
{
    Q_OBJECT

public:
    explicit fornecedor(QWidget *parent = nullptr);
    ~fornecedor();
    Conexao con;

private slots:
    void on_btn_salvar_clicked();

    void on_btn_cancelar_clicked();

private:
    Ui::fornecedor *ui;
};

#endif // FORNECEDOR_H
