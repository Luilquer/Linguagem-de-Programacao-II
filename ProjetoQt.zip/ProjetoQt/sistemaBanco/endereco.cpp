#include "endereco.h"
#include "ui_endereco.h"
#include <QMessageBox>
#include <QtSql>

Endereco::Endereco(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Endereco)
{
    ui->setupUi(this);
    //abrir o banco de dados
    if(!con.aberto()){
        if(!con.abrir()){
            QMessageBox::warning(this, "ERROR", "Erro ao abrir banco de Dados");
        }
    }
}

Endereco::~Endereco()
{
    delete ui;
}

void Endereco::on_btn_salvar_clicked()
{

    QString cidade=ui->txt_cidade->text();
    QString uf=ui->txt_uf->text();
    QString id=ui->txt_id->text();


    //INSERIR NA TABELA
    QSqlQuery query;
    query.prepare("insert into Endereco (cidade,uf,id_fornecedor) values"
                  "('"+cidade+"','"+uf+"','"+id+"')");

    if(!query.exec()){
         QMessageBox::critical(this, "ERRO", "Erro ao inserir no Banco de Dados");
    }else{
        QMessageBox::information(this, "GRAVADO", "inserido no Banco de Dados");
        //limpar todos os campos e posicipn
        ui->txt_cidade->clear();
        ui->txt_uf->clear();
        ui->txt_id->clear();
        ui->txt_cidade->setFocus();

    }

}

void Endereco::on_btn_cancelar_clicked()
{
    //limpar todos os campos e posicipn
    ui->txt_cidade->clear();
    ui->txt_uf->clear();
    ui->txt_id->clear();
    ui->txt_cidade->setFocus();
}
