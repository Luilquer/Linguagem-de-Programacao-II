#include "fornecedor.h"
#include "ui_fornecedor.h"
#include <QMessageBox>
#include <QtSql>

fornecedor::fornecedor(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fornecedor)
{
    ui->setupUi(this);
    //abrir o banco de dados
    if(!con.aberto()){
        if(!con.abrir()){
            QMessageBox::warning(this, "ERROR", "Erro ao abrir banco de Dados");
        }
    }
}

fornecedor::~fornecedor()
{
    delete ui;
}

void fornecedor::on_btn_salvar_clicked()
{
    QString nome=ui->txt_nome->text();

    //INSERIR NA TABELA
    QSqlQuery query;
    query.prepare("insert into Fornecedor (nome) values"
                  "('"+nome+"')");

    if(!query.exec()){
         QMessageBox::critical(this, "ERRO", "Erro ao inserir no Banco de Dados");
    }else{
        QMessageBox::information(this, "GRAVADO", "inserido no Banco de Dados");
        //limpar todos os campos
        ui->txt_nome->clear();
        ui->txt_nome->setFocus();

    }

}

void fornecedor::on_btn_cancelar_clicked()
{
    //limpar todos os campos
    ui->txt_nome->clear();
    ui->txt_nome->setFocus();
}
