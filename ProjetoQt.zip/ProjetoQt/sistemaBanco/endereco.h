#ifndef ENDERECO_H
#define ENDERECO_H

#include <QDialog>
#include <QObject>
#include "conexao.h"

namespace Ui {
class Endereco;
}

class Endereco : public QDialog
{
    Q_OBJECT

public:
    explicit Endereco(QWidget *parent = nullptr);
    ~Endereco();
    Conexao con;

private slots:
    void on_btn_salvar_clicked();

    void on_btn_cancelar_clicked();

private:
    Ui::Endereco *ui;
};

#endif // ENDERECO_H
