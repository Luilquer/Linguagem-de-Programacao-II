#include "logar.h"
#include "ui_logar.h"
#include <QMessageBox>
#include "principal.h"


logar::logar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::logar)
{
    ui->setupUi(this);
    logado=false;
}

logar::~logar()
{
    delete ui;
}

void logar::on_btn_logar_clicked()
{
    if(!con.abrir()){
        QMessageBox::warning(this, "Erro", "Erro ao abrir o banco de dados");
    }else{
        QString username,senha;
        username=ui->txt_username->text();
        senha=ui->txt_senha->text();
        QSqlQuery query;
        query.prepare("select * from Usuario where username='"+username+"' and senha='"+senha+"'");

        if(query.exec()){
            query.first();
            if(query.value(1).toString()!=""){
                logado=true;
                nome=query.value(1).toString();
                id=query.value(0).toInt();
                con.fechar();
                close();
            }else{
                QMessageBox::warning(this, "Erro", "Usuario não encontrado");
            }
        }else{
            QMessageBox::warning(this, "Erro", "Falha no login");
        }
    }
    //Login
    con.fechar();
}

void logar::on_btn_cancelar_clicked()
{
    logado=false;
    close();
}
