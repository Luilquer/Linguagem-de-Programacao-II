#ifndef BEBIDA_H
#define BEBIDA_H

#include <QDialog>
#include <QObject>
#include "conexao.h"

namespace Ui {
class bebida;
}

class bebida : public QDialog
{
    Q_OBJECT

public:
    explicit bebida(QWidget *parent = nullptr);
    ~bebida();
    Conexao con;

private slots:
    void on_btn_salvar_clicked();

    void on_btn_cancelar_clicked();

private:
    Ui::bebida *ui;
};

#endif // BEBIDA_H
