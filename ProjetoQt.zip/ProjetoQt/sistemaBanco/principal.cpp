#include "principal.h"
#include "ui_principal.h"
#include <QMessageBox>
#include "logar.h"
#include "usuario.h"
#include "bebida.h"
#include "fornecedor.h"
#include "endereco.h"

principal::principal(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::principal)
{
    ui->setupUi(this);
    logado=false;
}

principal::~principal()
{
    delete ui;
}


void principal::on_pushButton_clicked()
{
    if(!logado){
        //chamar tela tela desbloqueio
        logar f_logar;
        f_logar.exec();
        logado=true;

    }else{
        logado=false;

    }
}


//-----------------------Usuario--------------------------
void principal::on_actionUsuario_triggered()
{
    //verifica se existe Usuario logado
    if(logado){

            //cria um objeto do tipo
            usuario f_gestaousuario;
            //executa a janela
            f_gestaousuario.exec();

        //se for inserirdo dados que não constam no banco de dados
    }else{
         QMessageBox::information(this, "Login", "Não existe Usuario logado");
    }
}

//-----------------------Bebida--------------------------
void principal::on_actionBebida_triggered()
{
    if(logado){
            bebida f_gestaobebida;
            f_gestaobebida.exec();
        }else{
         QMessageBox::information(this, "Login", "Não existe Usuario logado");
    }
}

//-----------------------Fornecedor--------------------------
void principal::on_actionFornecedor_triggered()
{

    if(logado){

            fornecedor f_gestaofornecedor;
            f_gestaofornecedor.exec();

    }else{
         QMessageBox::information(this, "Login", "Não existe Usuario logado");
    }
}

//-----------------------Endereco--------------------------
void principal::on_actionEndereco_triggered()
{
    if(logado){

            Endereco f_gestaoEndereco;
            f_gestaoEndereco.exec();

    }else{
         QMessageBox::information(this, "Login", "Não existe Usuario logado");
    }
}
